#!/data/data/com.awnto.rinix.io/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt


exec ./$pfol/fil/d_install.sh > $log

#exec ./$pfol/fil/preboot.sh > $log



