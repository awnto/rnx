#!/data/data/com.awnto.rinix.io/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt







url_k9fatmx=http://127.0.0.1:8888/AWN/AWN/sev/rnx_k9_fatmx_prock_aarch64.tar.xz
url_k9rom=http://127.0.0.1:8888/AWN/AWN/sev/rnx_k9_linux_mini_via_termux_prock_aarch64.tar.xz

file_k9fatmx=/sdcard/AWN/rnx_k9_fatmx_prock_aarch64.tar.xz
file_k9rom=/sdcard/AWN/rnx_k9_linux_prock_aarch64.tar.xz





if test -f $HOME/linux/awnto/prock ;
then
	rnx_tog ENTER_1_EXISTS
else
	rnx_tog ENTER_1
	#rnx_tog DOWNLOADING_FATMX_[20MB]
	#mkdir -p $HOME/uDown
	
	if test -f $file_k9rom
	then
		rnx_tog INSTALLING_K9ROM
		rm -rf $HOME/linux
		mkdir -p $HOME/linux	
		cd $HOME/linux
		
		if tar -xJf $file_k9rom
		then
			rnx_tog INSTALL_K9ROM_DONE
		else
			rnx_tog INSTALL_K9ROM_FAIL
		fi
		
	fi
fi



if test -f $HOME/linux/awnto/prock ;
then
	rnx_tog ENTER_2_EXISTS
else
	rnx_tog ENTER_2
	rnx_tog DOWNLOADING_K9ROM_[260MB]
	mkdir -p $HOME/uDown
	
	(( ict = 0 ))
	if rogg curl --output $HOME/uDown/k9rom.tar.xz $url_k9rom
	then
		(( ict = 1 ))
		chmod 700 $HOME/uDown/k9rom.tar.xz
	fi
	if (( ict == 1 ))
	then
		rnx_tog INSTALLING_K9ROM
		rm -rf $HOME/linux
		mkdir -p $HOME/linux		
		cd $HOME/linux
		
		sleep 1
		
		if tar -xJf $HOME/uDown/k9rom.tar.xz
		then
			rnx_tog INSTALL_K9ROM_DONE
			rm -rf $HOME/uDown/k9rom.tar.xz
		else
			rnx_tog INSTALL_K9ROM_FAIL
			rm -rf $HOME/linux/awnto/prock
			rm -rf $HOME/uDown/k9rom.tar.xz
			sleep 1
			exit 13
		fi
		
	fi
	#rm -rf $HOME/uDown/k9rom.tar.xz
fi

if ! test -f $HOME/linux/awnto/prock ;
then
	rnx_tog ENTER_3
	rnx_tog K9ROM_INSTALL_FAIL
	sleep 1
	exit 11 	
fi








if test -f $HOME/fatmx/prock ;
then
	rnx_tog ENTER_4_EXISTS
else
	rnx_tog ENTER_4
	#rnx_tog DOWNLOADING_FATMX_[20MB]
	#mkdir -p $HOME/uDown
	
	if test -f $file_k9fatmx
	then
		rnx_tog INSTALLING_FATMX
		rm -rf $HOME/fatmx
		mkdir -p $HOME/fatmx		
		cd $HOME/fatmx
		
		if tar -xJf $file_k9fatmx
		then
			rnx_tog INSTALL_FATMX_DONE
		else
			rnx_tog INSTALL_FATMX_FAIL
		fi
		
	fi
	
fi



if test -f $HOME/fatmx/prock ;
then
	rnx_tog ENTER_5_EXISTS
else
	rnx_tog ENTER_5
	rnx_tog DOWNLOADING_FATMX_[20MB]
	mkdir -p $HOME/uDown
	
	(( ict = 0 ))
	
	if rogg curl --output $HOME/uDown/fatmx.tar.xz $url_k9fatmx
	then
		(( ict = 1 ))
		chmod 700 $HOME/uDown/fatmx.tar.xz
	fi
	if (( ict == 1 ))
	then
		rnx_tog INSTALLING_FATMX
		rm -rf $HOME/fatmx
		mkdir -p $HOME/fatmx		
		cd $HOME/fatmx
		
		sleep 1
		
		if tar -xJf $HOME/uDown/fatmx.tar.xz
		then
			rnx_tog INSTALL_FATMX_DONE
			rm -rf $HOME/uDown/fatmx.tar.xz
		else
			rnx_tog INSTALL_FATMX_FAIL
			rm -rf $HOME/fatmx/prock
			rm -rf $HOME/uDown/fatmx.tar.xz
			sleep 1
			exit 15
		fi
		
	fi
	#rm -rf $HOME/uDown/fatmx.tar.xz
fi

if ! test -f $HOME/fatmx/prock ;
then
	rnx_tog ENTER_6
	rnx_tog FATMX_INSTALL_FAIL
	sleep 1
	exit 11 	
fi





rnx_tog CHECK_POINT_3
exit



