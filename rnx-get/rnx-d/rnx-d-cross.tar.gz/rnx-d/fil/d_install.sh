#!/data/data/com.awnto.rinix.io/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt






(( ict = 1 ))
(( ict_k9rom = 1 ))
(( ict_k9fatmx = 1 ))

rnx_tog D_INSTALL









if ! test -f $HOME/linux/awnto/prock ;
then
	
	rnx_tog RNX_OS_INSTALLING
	
	cd
	rm -rf linux
	mkdir -p linux
	cd linux
	tar -xJf /sdcard/AWN/rnx_k9_linux_prock_aarch64.tar.xz 
	
	rnx_tog RNX_OS_INSTALL_DONE

fi



if ! test -f $HOME/linux/awnto/prock ;
then
	
	rnx_tog RNX_OS_INSTALLING
	
	cd
	rm -rf linux
	mkdir -p linux
	cd linux
	
	
	
	if ! test -f /sdcard/AWN/rnx_k9_linux_prock_aarch64.tar.xz
	then
		rnx_tog "K9ROM_NOT_FOUND_VISIT_>>>RINIX.AWNTO.COM<<<"
		#exit
	fi
	

	if tar -xJf /sdcard/AWN/rnx_k9_linux_prock_aarch64.tar.xz
	then
		rnx_tog INSTALLING_K9ROM_DONE 
	else
		rnx_tog SYSTEM_FAIL_CHECK_K9ROM_FILE 
		
		(( ict_k9rom = 0 ))
	fi
fi



if (( ict_k9rom == 0 )) ;
then
	
	cd 
	
	rm -rvf linux
	mkdir -p linux
	cd linux
	
	(( ict_k9rom = 1 ))

	rnx_tog DOWNLOADING_K9ROM
	
	#if wget -O $HOME/uDown/k9rom.tar.xz http://awnto.com
	if curl --output $HOME/uDown/k9rom.tar.xz http://awnto.com
	then
		(( ict_k9rom = 0 ))
		rnx_tog DOWNLOADING_K9ROM_FAIL
	fi
	
	
	if (( ict_k9rom == 1 ))
	then
	
	
	if tar -xJf $HOME/uDown/k9rom.tar.xz
	then
		rnx_tog INSTALLING_K9ROM_SYSTEM_DONE
	else
		rnx_tog SYSTEM_FAIL_CHECK_k9ROM_FILE
		
		(( ict_k9fatmx = 0 ))
	fi
	
	fi
	
	rm -rf $HOME/uDown/k9rom.tar.xz
	

fi


if ! test -f $HOME/linux/awnto/prock ;
then
	
	(( ict = 0 ))
	(( ict_k9rom = 0 ))
	rnx_tog RNX_OS_INSTALL_FAIL

fi







if ! test -f $HOME/fatmx/prock ;
then
	
	rnx_tog INSTALLING_FATMX_SYSTEM 

	cd 
	rm -rvf fatmx
	mkdir -p fatmx
	cd fatmx
	
	
	
	
	if ! test -f /sdcard/AWN/rnx_k9_fatmx_prock_aarch64.tar.xz
	then
		rnx_tog "FATMX_SYSTEM_NOT_FOUND_VISIT_>>>RINIX.AWNTO.COM<<<"
		#exit
	fi
	

	if tar -xJf /sdcard/AWN/rnx_k9_fatmx_prock_aarch64.tar.xz
	then
		rnx_tog INSTALLING_FATMX_SYSTEM_DONE 
	else
		rnx_tog SYSTEM_FAIL_CHECK_FATMX_FILE 
		
		(( ict_k9fatmx = 0 ))
	fi
fi



if ! test -f $HOME/fatmx/prock ;
then
	
	cd 
	rm -rvf fatmx
	mkdir -p fatmx
	cd fatmx

	
	(( ict_k9fatmx = 1 ))

	rnx_tog DOWNLOADING_FATMX
	
	if wget -O $HOME/uDown/fatmx.tar.xz http://rnx.awnto.com/rnx-get/files/fatmx/rnx_k9_fatmx_prock_aarch64.tar.xz
	then
		(( ict_k9fatmx = 0 ))
		rnx_tog DOWNLOADING_FATMX_FAIL
	fi
	
	
	if (( ict_k9fatmx == 1 ))
	then
	
	
	if tar -xJf $HOME/uDown/fatmx.tar.xz
	then
		rnx_tog INSTALLING_FATMX_SYSTEM_DONE
	else
		rnx_tog SYSTEM_FAIL_CHECK_FATMX_FILE
		
		(( ict_k9fatmx = 0 ))
	fi
	
	fi
	
	rm -rf $HOME/uDown/fatmx.tar.xz
	

fi



if ! test -f $HOME/.fatmx/prock ;
then
	
	(( ict = 0 ))
	(( ict_k9fatmx = 0 ))
	rnx_tog RNX_OS_INSTALL_FAIL

fi






if (( ict == 1 ))
then

	echo accor.. starting
	rnx_tog ACOOR_STARTING
	#exec ./$pfol/fil/preboot.sh > $log
       cd $pdir
        exec ./$pfol/fil/preboot.sh

else

	sleep 2
	rnx_tog RECHECKING_D_INSTALL
	sleep 1
	#exec /data/data/com.awnto.rinix.io/files/assets/data/boot.sh
	cd $pdir
	exec ./$pfol/fil/d_install.sh

fi







