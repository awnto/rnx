#!/data/data/com.awnto.rinix.io/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt






(( ict = 1 ))


rnx_tog D_INSTALL









if ! test -f $HOME/linux/awnto/status ;
then
	
	rnx_tog RNX_OS_INSTALLING
	
	cd
	mkdir -p linux
	cd linux
	tar -xJf /sdcard/AWN/rnx_k9_linux.tar.xz 
	
	rnx_tog RNX_OS_INSTALL_DONE

fi
if ! test -f $HOME/linux/awnto/status ;
then
	
	(( ict = 0 ))
	rnx_tog RNX_OS_INSTALL_FAIL

fi







if ! test -f /data/data/com.awnto.rinix.io/files/home/.fatmx/prock ;
then
	
	rnx_tog INSTALLING_FATMX_SYSTEM 

	cd
	
	
	
	
	if ! test -f /sdcard/AWN/rnx_k9_fatmx_prock.tar.xz
	then
		rnx_tog "FATMX_SYSTEM_NOT_FOUND_VISIT_>>>RINIX.AWNTO.COM<<<"
		#exit
	fi
	

	if /data/data/com.awnto.rinix.io/files/assets/data/busybox tar -xJf /sdcard/AWN/rnx_k9_fatmx_prock.tar.xz
	then
		rnx_tog INSTALLING_FATMX_SYSTEM_DONE > $HOME/rnx_tog.txt
	else
		rnx_tog SYSTEM_FAIL_CHECK_FATMX_FILE > $HOME/rnx_tog.txt
		(( ict = 0 ))
	fi
fi





if (( ict == 1 ))
then

	echo accor.. starting
	rnx_tog ACOOR_STARTING
	#exec ./$pfol/fil/preboot.sh > $log
       cd $pdir
        exec ./$pfol/fil/preboot.sh

else

	sleep 2
	echo RECHECKING_D_INSTALL > $HOME/rnx_tog.txt
	sleep 1
	#exec /data/data/com.awnto.rinix.io/files/assets/data/boot.sh
	cd $pdir
	exec ./$pfol/fil/d_install.sh

fi







