#!/data/data/com.awnto.rinix.io/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir


cd $pfol/fil/rcv/var


rm ../inet.sh
wget http://rinix.awnto.com/rnx-get/files/inet.sh -O ../inet.sh
chmod 755 ../inet.sh
../inet.sh

../post.sh






