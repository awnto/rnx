#!/data/data/com.awnto.rinix.io/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

clear

cat $pfol/fil/rcv/profile.txt

$PREFIX/bin/rnx auto
# >> /dev/null


cd
