#!/data/data/com.awnto.rinix.io/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir


#cat $pfol/fil/rcv/welcome.txt
./$pfol/fil/rcv/welcome.sh


exit


im_wax_wel=`cat $pfol/im/vari/rnx_rfl`/awnto/wax/welcome.txt

if test -f $im_wax_wel ;
then
echo "-------- awnto wax services --------"

#/awnto/wax/orc
cat $im_wax_wel

echo "-----------------------------------"
fi




./$pfol/fil/im.sh /awnto/im/native

exit





